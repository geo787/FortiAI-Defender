# Ai

This folder will contain ai code or documents.